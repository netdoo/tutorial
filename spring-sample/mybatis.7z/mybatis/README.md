MVC 기반의 Hello world 예제
=================


본 예제를 통해서, REST 방식의 통신과 JSTL 그리고,
GET으로 요청된 Param 을 처리하는 방법에 대해서 이해할 수 있습니다.
